## [1.4.0] - 2022-05-06
### Updates
- update to Angular 13
- update all dependencies to match Angular 13 version
- routing issue fixed
## [1.3.0] - 2020-12-17
### Updates
- update to Angular 11
- update all dependencies to match Angular 11 version

## [1.2.0] - 2020-03-13
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.1.0] - 2019-02-11
### Changes
- update to Angular 7
- update ng-bootstrap to version 4
- update all dependencies to latest versions

## [1.0.0] - 2018-05-17
### Initial Release
